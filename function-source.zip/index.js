'use strict';

const functions = require('firebase-functions');
const { WebhookClient } = require('dialogflow-fulfillment');
const { Card, Suggestion } = require('dialogflow-fulfillment');

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

exports.dialogflowFirebaseFulfillment = functions.https.onRequest(
  (request, response) => {
    const agent = new WebhookClient({ request, response });
    console.log(
      'Dialogflow Request headers: ' + JSON.stringify(request.headers)
    );
    console.log('Dialogflow Request body: ' + JSON.stringify(request.body));

    const flightDataObj = {
      'new york': {
        'los angeles': {
          cost: '450',
          time: '12 pm',
          airline: 'Hippogriff Air Lines',
        },
        'las vegas': {
          cost: '340',
          time: '2 pm',
          airline: 'Lightning Airways',
        },
        seattle: {
          cost: '470',
          time: '11 am',
          airline: 'Harpy Intercontinental',
        },
        boston: {
          cost: '150',
          time: '7 pm',
          airline: 'Lightning Airways',
        },
        chicago: {
          cost: '250',
          time: '3 pm',
          airline: 'Hippogriff Air Lines',
        },
        'san francisco': {
          cost: '520',
          time: '8 am',
          airline: 'Griffin Air',
        },
      },
      'los angeles': {
        'new york': {
          cost: '450',
          time: '12 pm',
          airline: 'Hippogriff Air Lines',
        },
        'las vegas': {
          cost: '140',
          time: '2 pm',
          airline: 'Lightning Airways',
        },
        seattle: {
          cost: '180',
          time: '11 am',
          airline: 'Harpy Intercontinental',
        },
        boston: {
          cost: '470',
          time: '4 pm',
          airline: 'Lightning Airways',
        },
        chicago: {
          cost: '250',
          time: '3 pm',
          airline: 'Hippogriff Air Lines',
        },
        'san Francisco': {
          cost: '220',
          time: '8 am',
          airline: 'Griffin Air',
        },
      },
      'las vegas': {
        'new york': {
          cost: '450',
          time: '12 pm',
          airline: 'Hippogriff Air Lines',
        },
        'los angeles': {
          cost: '150',
          time: '2 pm',
          airline: 'Lightning Airways',
        },
        seattle: {
          cost: '270',
          time: '11 am',
          airline: 'Harpy Intercontinental',
        },
        boston: {
          cost: '350',
          time: '4 pm',
          airline: 'Lightning Airways',
        },
        chicago: {
          cost: '250',
          time: '3 pm',
          airline: 'Hippogriff Air Lines',
        },
        'san francisco': {
          cost: '520',
          time: '8 am',
          airline: 'Griffin Air',
        },
      },
      seattle: {
        'new york': {
          cost: '450',
          time: '12 pm',
          airline: 'Hippogriff Air Lines',
        },
        'los angeles': {
          cost: '340',
          time: '2 pm',
          airline: 'Lightning Airways',
        },
        'las vegas': {
          cost: '150',
          time: '11 am',
          airline: 'Harpy Intercontinental',
          departureAirport: 'SEA',
          arrivalAirport: 'LAS',
          departureTime: '11:00 AM PST',
          arrivalTime: '01:35 PM PST',
        },
        boston: {
          cost: '270',
          time: '5 pm',
          airline: 'Lightning Airways',
        },
        chicago: {
          cost: '250',
          time: '3 pm',
          airline: 'Hippogriff Air Lines',
        },
        'san francisco': {
          cost: '220',
          time: '8 am',
          airline: 'Griffin Air',
        },
      },
      boston: {
        'new york': {
          cost: '450',
          time: '12 pm',
          airline: 'Hippogriff Air Lines',
        },
        'los angeles': {
          cost: '340',
          time: '2 pm',
          airline: 'Lightning Airways',
        },
        'las vegas': {
          cost: '470',
          time: '11 am',
          airline: 'Harpy Intercontinental',
        },
        seattle: {
          cost: '150',
          time: '7 pm',
          airline: 'Lightning Airways',
        },
        chicago: {
          cost: '250',
          time: '3 pm',
          airline: 'Hippogriff Air Lines',
        },
        'san francisco': {
          cost: '520',
          time: '8 am',
          airline: 'Griffin Air',
        },
      },
      chicago: {
        'new york': {
          cost: '450',
          time: '12 pm',
          airline: 'Lightning Airways',
        },
        'los angeles': {
          cost: '340',
          time: '2 pm',
          airline: 'Lightning Airways',
        },
        'las vegas': {
          cost: '470',
          time: '11 am',
          airline: 'Harpy Intercontinental',
        },
        seattle: {
          cost: '150',
          time: '7 pm',
          airline: 'Lightning Airways',
        },
        boston: {
          cost: '250',
          time: '3 pm',
          airline: 'Hippogriff Air Lines',
        },
        'san francisco': {
          cost: '520',
          time: '8 am',
          airline: 'Griffin Air',
        },
      },
      'san francisco': {
        'new york': {
          cost: '450',
          time: '12 pm',
          airline: 'Lightning Airways',
        },
        'los angeles': {
          cost: '340',
          time: '2 pm',
          airline: 'Hippogriff Air Lines',
        },
        'las vegas': {
          cost: '470',
          time: '11 am',
          airline: 'Harpy Intercontinental',
        },
        seattle: {
          cost: '150',
          time: '7 pm',
          airline: 'Lightning Airways',
        },
        boston: {
          cost: '250',
          time: '3 pm',
          airline: 'Harpy Intercontinental',
        },
        chicago: {
          cost: '520',
          time: '8 am',
          airline: 'Griffin Air',
        },
      },
    };
    function getToCityList(cityFrom) {
      if (cityFrom && flightDataObj[cityFrom]) {
        return flightDataObj[cityFrom];
      }
      return {
        city: '',
      };
    }

    function lowBudgetVacationHandler(agent) {
      const fromcity = agent.parameters.fromcity;
      const flightDataItems = getToCityList(fromcity.toLowerCase());
      if (flightDataItems.city === '') {
        agent.add(`Sorry, I couldn't find any flights from ${fromcity}`);
      } else {
        let min = Number.MAX_SAFE_INTEGER;
        let toCityName = '';
        for (const [cityName, flightData] of Object.entries(flightDataItems)) {
          min = Math.min(flightData.cost, min);
          if (min == flightData.cost) {
            toCityName = cityName;
          }
        }
        let lowBudgetFlightData = flightDataItems[toCityName];
        agent.add(`The most economical flight from ${fromcity} will cost $${lowBudgetFlightData.cost} is flying to ${toCityName} 
   	 	at ${lowBudgetFlightData.time} tomorrow with ${lowBudgetFlightData.airline}.`);
      }
    }

    function whereToGoVacationHandler(agent) {
      const fromcity = agent.parameters.fromcity;
      const number = agent.parameters.number;
      const duration = agent.parameters.durationAmount;
      const flightData = getToCityList(fromcity.toLowerCase());
      if (flightData.city === '') {
        agent.add(`Sorry, I couldn't find any flights from ${fromcity}`);
      } else {
        const cityArr = Object.keys(flightData);
        let newCityArr = [];
        if (Number.isInteger(number)) {
          newCityArr = limitCityArrSize(cityArr, number);
        } else if (duration) {
          let shortDuration = ['short', 'brief', 'small'];
          if (shortDuration.includes(duration)) {
            newCityArr = limitCityArrSize(cityArr, 1);
          } else {
            newCityArr = cityArr;
          }
        } else {
          newCityArr = cityArr;
        }
        agent.add(
          `From ${fromcity}, you can travel to ${newCityArr.join(', ')}`
        );
      }
    }

    const limitCityArrSize = (arr, quantity) => {
      if (arr.length > quantity) {
        return arr.slice(0, quantity);
      }
      return arr;
    };

    function getFlightData(cityFrom, cityTo) {
      if (
        cityFrom &&
        flightDataObj[cityFrom] &&
        cityTo &&
        flightDataObj[cityFrom][cityTo]
      ) {
        return flightDataObj[cityFrom][cityTo];
      }
      return {
        cost: '',
      };
    }

    function searchCheapestFlightHandler(agent) {
      const fromcity = agent.parameters.fromcity;
      const tocity = agent.parameters.tocity;
      const flightData = getFlightData(
        fromcity.toLowerCase(),
        tocity.toLowerCase()
      );
      if (flightData.cost === '') {
        agent.add(
          `Sorry, I couldn't find any flights from ${fromcity} to ${tocity}.`
        );
      } else {
        agent.add(`The Cheapest flight from ${fromcity} to ${tocity} is $${flightData.cost}.\n
   		It is at ${flightData.time} tomorrow with ${flightData.airline}.`);
      }
    }

    let intentMap = new Map();
    intentMap.set('SearchCheapestFlightIntent', searchCheapestFlightHandler);
    intentMap.set('WhereToGoVacationIntent', whereToGoVacationHandler);
    intentMap.set('LowBudgetVacationIntent', lowBudgetVacationHandler);
    agent.handleRequest(intentMap);
  }
);
